import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const OBShopApp());

class OBShopApp extends StatefulWidget {
  const OBShopApp({super.key});
  @override
  State<OBShopApp> createState() => _OBShopAppState();
}

class _OBShopAppState extends State<OBShopApp> {
  ThemeMode themeMode = ThemeMode.dark;
  String language = 'Türkmençe';
  final List<ShopProduct> cart = [];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'O.B Awto Bezegleri',
      themeMode: themeMode,
      theme: ThemeData(
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xffa83232)),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xffb83232),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xff101318),
        cardColor: const Color(0xff1c222b),
        useMaterial3: true,
      ),
      home: SplashGate(
        child: ShopHome(
          language: language,
          onLanguage: (v) => setState(() => language = v),
          isDark: themeMode == ThemeMode.dark,
          onTheme: (v) => setState(() => themeMode = v ? ThemeMode.dark : ThemeMode.light),
          cart: cart,
          onAdd: (p) => setState(() => cart.add(p)),
        ),
      ),
    );
  }
}

class SplashGate extends StatefulWidget {
  final Widget child;
  const SplashGate({super.key, required this.child});
  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  bool show = true;
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      if (mounted) setState(() => show = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!show) return widget.child;
    return Scaffold(
      backgroundColor: const Color(0xff101318),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Image.asset('assets/logo_dark.png', fit: BoxFit.contain),
        ),
      ),
    );
  }
}

class ShopProduct {
  final String name;
  final String category;
  final String description;
  final String price;
  final IconData icon;
  const ShopProduct(this.name, this.category, this.description, this.price, this.icon);
}

const products = <ShopProduct>[
  ShopProduct('LED far seti', 'Aydınlatma', 'Araç içi ve dışı kullanım için LED aksesuar.', 'Fiyat için iletişime geçin', Icons.lightbulb_outline),
  ShopProduct('Karbon görünümlü kaplama', 'İç aksesuar', 'İç mekân için dekoratif kaplama.', 'Fiyat için iletişime geçin', Icons.dashboard_customize),
  ShopProduct('Telefon tutucu', 'Elektronik', 'Araç içi telefon tutucu.', 'Fiyat için iletişime geçin', Icons.phone_iphone),
  ShopProduct('Direksiyon kılıfı', 'İç aksesuar', 'Farklı araçlara uygun direksiyon aksesuarı.', 'Fiyat için iletişime geçin', Icons.radio_button_checked),
];

class ShopHome extends StatelessWidget {
  final String language;
  final ValueChanged<String> onLanguage;
  final bool isDark;
  final ValueChanged<bool> onTheme;
  final List<ShopProduct> cart;
  final ValueChanged<ShopProduct> onAdd;

  const ShopHome({
    super.key, required this.language, required this.onLanguage,
    required this.isDark, required this.onTheme, required this.cart, required this.onAdd,
  });

  String tr(String t, String tk, String ru) =>
      language == 'Türkçe' ? t : language == 'Русский' ? ru : tk;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('O.B AWTO BEZEGleri', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Dil / Язык',
            icon: const Icon(Icons.language),
            onSelected: onLanguage,
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'Türkçe', child: Text('Türkçe')),
              PopupMenuItem(value: 'Türkmençe', child: Text('Türkmençe')),
              PopupMenuItem(value: 'Русский', child: Text('Русский')),
            ],
          ),
          IconButton(icon: const Icon(Icons.search), onPressed: () => showSearch(context: context, delegate: ProductSearch())),
          IconButton(icon: Icon(isDark ? Icons.light_mode : Icons.dark_mode), onPressed: () => onTheme(!isDark)),
        ],
      ),
      drawer: Drawer(
        child: ListView(padding: EdgeInsets.zero, children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Color(0xff252b35)),
            child: Align(alignment: Alignment.bottomLeft, child: Text('O.B AWTO BEZEGleri', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
          ),
          ListTile(leading: const Icon(Icons.home), title: Text(tr('Ana sayfa','Baş sahypa','Главная')), onTap: () => Navigator.pop(context)),
          ListTile(leading: const Icon(Icons.directions_car), title: Text(tr('Araç modelleri','Awtoulag modelleri','Модели автомобилей')), onTap: () => _info(context, tr('Araç modelleri yakında eklenecek.','Awtoulag modelleri soň goşular.','Модели автомобилей будут добавлены позже.'))),
          ListTile(leading: const Icon(Icons.shopping_bag), title: Text(tr('Sepetim','Sebedim','Корзина (${cart.length})')), onTap: () { Navigator.pop(context); _cart(context); }),
          ListTile(leading: const Icon(Icons.person), title: Text(tr('Üyelik / Giriş','Agza bolmak / Giriş','Регистрация / Вход')), onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => const MembershipPage())); }),
          ListTile(leading: const Icon(Icons.settings), title: Text(tr('Ayarlar','Sazlamalar','Настройки')), onTap: () => _info(context, tr('Dil ve tema ayarları sağ üsttedir.','Dil we tema sazlamalary ýokarda.','Язык и тема находятся сверху.'))),
          const Divider(),
          const ListTile(leading: Icon(Icons.admin_panel_settings), title: Text('Yönetici paneli'), subtitle: Text('Güvenli sunucu bağlantısı kurulduğunda etkinleştirilecek.')),
        ]),
      ),
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tr('Aracına değer kat.','Awtoulagyňa aýratynlyk goş.','Добавьте стиль вашему автомобилю.'),
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(tr('Otomobil aksesuarları ve özel ürünler.','Awtoulag esbaplary we ýörite önümler.','Автоаксессуары и специальные товары.'),
                style: TextStyle(color: Theme.of(context).hintColor)),
              const SizedBox(height: 16),
              Container(
                width: double.infinity, padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: const LinearGradient(colors: [Color(0xff5c2024), Color(0xff242a34)]),
                ),
                child: Row(children: [
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('O.B', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: Colors.white)),
                    Text('AWTO BEZEGleri', style: TextStyle(letterSpacing: 1.2, color: Colors.white, fontWeight: FontWeight.bold)),
                  ])),
                  const Icon(Icons.directions_car_filled, size: 58, color: Colors.white70),
                ]),
              ),
              const SizedBox(height: 20),
              Text(tr('Ürünler','Önümler','Товары'), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate((context, i) {
              final p = products[i];
              return Card(
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductPage(product: p, onAdd: onAdd))),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Expanded(child: Center(child: Icon(p.icon, size: 54, color: const Color(0xffc64a4a)))),
                      Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(p.category, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
                      const SizedBox(height: 6),
                      Text(p.price, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
                    ]),
                  ),
                ),
              );
            }, childCount: products.length),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .88),
          ),
        ),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _cart(context),
        icon: const Icon(Icons.shopping_cart),
        label: Text('${tr('Sepet','Sebet','Корзина')} (${cart.length})'),
      ),
    );
  }

  void _cart(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => CartPage(cart: cart)));
  }

  void _info(BuildContext context, String message) {
    showDialog(context: context, builder: (_) => AlertDialog(content: Text(message), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tamam'))]));
  }
}

class ProductPage extends StatelessWidget {
  final ShopProduct product;
  final ValueChanged<ShopProduct> onAdd;
  const ProductPage({super.key, required this.product, required this.onAdd});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(product.name)),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Center(child: Icon(product.icon, size: 120, color: const Color(0xffc64a4a)))),
      Text(product.name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text(product.price, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xffd56a6a))),
      const SizedBox(height: 12),
      Text(product.description),
      const SizedBox(height: 12),
      const Text('Yorumlar', style: TextStyle(fontWeight: FontWeight.bold)),
      const Text('Henüz yorum yok. Üyelik ve yorum sistemi sunucu bağlantısından sonra etkinleşecek.'),
      const SizedBox(height: 20),
      SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () { onAdd(product); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ürün sepete eklendi'))); }, icon: const Icon(Icons.add_shopping_cart), label: const Text('Sepete ekle'))),
    ])),
  );
}

class CartPage extends StatelessWidget {
  final List<ShopProduct> cart;
  const CartPage({super.key, required this.cart});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Sepetim')),
    body: cart.isEmpty ? const Center(child: Text('Sepetiniz boş.')) : ListView(
      children: [
        ...cart.map((p) => ListTile(leading: Icon(p.icon), title: Text(p.name), subtitle: Text(p.price))),
        Padding(padding: const EdgeInsets.all(16), child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MembershipPage())), child: const Text('Sipariş için giriş yap'))),
      ],
    ),
  );
}

class MembershipPage extends StatefulWidget {
  const MembershipPage({super.key});
  @override
  State<MembershipPage> createState() => _MembershipPageState();
}
class _MembershipPageState extends State<MembershipPage> {
  final phone = TextEditingController();
  @override
  void dispose() { phone.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Üyelik başvurusu')),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Telefon numaranızı girin', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Bu başlangıç sürümünde başvuru ekranı örnektir. Gerçek kayıt, telefon doğrulaması ve yönetici onayı güvenli sunucu kurulduktan sonra çalışacaktır.'),
      const SizedBox(height: 20),
      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Telefon numarası', border: OutlineInputBorder(), prefixIcon: Icon(Icons.phone))),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, child: FilledButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sunucu bağlantısı kurulunca başvurunuz gönderilecek.'))), child: const Text('Başvuru gönder'))),
    ])),
  );
}

class ProductSearch extends SearchDelegate<String> {
  @override
  String get searchFieldLabel => 'Ürün ara';
  @override
  List<Widget> buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override
  Widget buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override
  Widget buildResults(BuildContext context) => _results();
  @override
  Widget buildSuggestions(BuildContext context) => _results();
  Widget _results() {
    final found = products.where((p) => p.name.toLowerCase().contains(query.toLowerCase())).toList();
    return ListView(children: found.map((p) => ListTile(leading: Icon(p.icon), title: Text(p.name), subtitle: Text(p.category))).toList());
  }
}
