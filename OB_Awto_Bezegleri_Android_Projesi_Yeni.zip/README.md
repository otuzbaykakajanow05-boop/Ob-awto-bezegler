# O.B Awto Bezegleri — başlangıç Android projesi

Bu paket, Flutter tabanlı çalışan bir **arayüz prototipidir**.

## İçindekiler
- 2 saniyelik açılış ekranı ve yüklenen koyu logo
- Koyu tema varsayılan, açık/koyu tema değiştirme
- Türkçe, Türkmence ve Rusça dil seçimi (ilk arayüz metinleri)
- Ürün kartları ve ürün detay sayfası
- Arama, sepet ve telefon numarası üyelik başvuru ekranı
- Yönetici paneli için yer tutucu

## Önemli
Bu ilk sürüm gerçek mağaza altyapısı değildir. Ürünler örnek veridir; sepet cihaz belleğindedir.
Telefon numarası kaydetme, SMS doğrulama, yönetici onayı, gerçek yönetici paneli, çevrimiçi sipariş,
kurye akışı, yorumlar, veritabanı, yedekleme ve sunucu güvenliği henüz bağlı değildir.
Bunlar gerçek kullanıcı verisi toplamadan önce güvenli bir backend ile tamamlanmalıdır.
Bu prototipte gerçek telefon numarası girmeyin.

## APK oluşturma
En kolay yol GitHub Actions:
1. GitHub'da boş bir repository oluşturun.
2. Bu ZIP'in içeriğini repository'ye yükleyin.
3. Actions sekmesinden **Build Android APK** iş akışını çalıştırın.
4. Tamamlandığında workflow'un Artifacts bölümünden `ob-awto-bezegleri-apk` dosyasını indirin.
5. ZIP içindeki APK'yı Android telefonunuza aktarın ve kurun.

Alternatif olarak Flutter SDK kurulu bir bilgisayarda:
```bash
flutter pub get
flutter build apk --release
```
APK yolu: `build/app/outputs/flutter-apk/app-release.apk`
